package jo.digout;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {
    private TextView tv1,tv4;
    private RadioButton rb1;
     private RadioButton rb2,rb3,radio;
    private EditText tf1;
    private RadioGroup rg1;
    private Button b1;
    private CheckBox c1,chk;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        rg1 = (RadioGroup) findViewById(R.id.radiochoice);
        tf1 = (EditText) findViewById(R.id.tf1);
        tv1 = (TextView) findViewById(R.id.tv1);
        tv1.setMaxLines(20);
        c1 =(CheckBox) findViewById(R.id.c1);
        rb1 =(RadioButton) findViewById(R.id.rb1);
        rb2 = (RadioButton) findViewById(R.id.rb2);
        rb3 = (RadioButton) findViewById(R.id.rb3);
        b1 = (Button) findViewById(R.id.b1);
        tv4=(TextView) findViewById(R.id.tv4);
        //tv4.setText( Html.fromHtml("<a href=http://www.anonhack.in>Visit for Knowledge</a> "));
        //tv4.setMovementMethod(LinkMovementMethod.getInstance());
        addListenerOnButton();


            tv4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent browserIntent1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.anonhack.in"));
                startActivity(browserIntent1);
            }
        });

    }

    public void addListenerOnButton() {
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userin = tf1.getText().toString();
                int selectedId = rg1.getCheckedRadioButtonId();

                radio = (RadioButton) findViewById(selectedId);
                //chk = (CheckBox) findViewById(selectedId);
                if (rg1.getCheckedRadioButtonId() == -1) {
                    Toast.makeText(MainActivity.this, "Select one of the above option first!", Toast.LENGTH_SHORT).show();
                } else {

                    if (c1.isChecked()) {
                        try {
                            directory(userin, radio);
                        } catch (URISyntaxException e) {
                            Toast.makeText(MainActivity.this,
                                    "Select one of the two options", Toast.LENGTH_SHORT).show();
                        } catch (IOException e) {
                            Toast.makeText(MainActivity.this,
                                    "Select one of the two options", Toast.LENGTH_SHORT).show();
                        }
                    } else {

                        try {
                            request(userin, radio);
                        } catch (URISyntaxException e) {
                            Toast.makeText(MainActivity.this,
                                    "Select one of the two options", Toast.LENGTH_SHORT).show();
                        } catch (IOException e) {
                            Toast.makeText(MainActivity.this,
                                    "Select one of the two options", Toast.LENGTH_SHORT).show();
                        }
                        Toast.makeText(MainActivity.this,
                                radio.getText(), Toast.LENGTH_SHORT).show();
                    }
                }
            }

        });
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    private void dig(){
        String user=tf1.getText().toString();
        rb1.isSelected();


    }
    void directory(CharSequence uri,RadioButton n)throws URISyntaxException,IOException{
        String u1=null;
        String perma="intitle:\"index.of\"";
        String Goog="https://www.google.com/search?q=";
        switch(n.getText().toString()){
            case "Book": u1=perma+ uri +" pdf | book | epub | chm";
                break;
            case "Music":u1=perma+ uri +" mp3 | music";
                break;
            case "Video":u1=perma + uri + " mp4 | mkv | flv | avi";
                break;
            default: Toast.makeText(MainActivity.this,
                    "Select the appropriate option", Toast.LENGTH_SHORT).show();

        }
        try{

            String FinReq=Goog+ URLEncoder.encode(u1, "UTF-8");
            //System.out.println(FinReq);

            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(FinReq));
            startActivity(browserIntent);

        } catch (UnsupportedEncodingException e) {

            System.err.println(e);

        }


    }
    void request(CharSequence uri, RadioButton n) throws URISyntaxException, IOException{
        String u2 = null;
        String GooURL;
        switch(n.getText().toString()){
            case "Book":u2="inurl:"+uri+" | intitle:"+uri+" ext:pdf ext:\"chm|epub\" | download inurl:(PDF|chm|epub)";
                break;
            case "Music":u2="inurl:"+uri+" | intitle:"+uri+" ext:mp3 | download inurl:(mp3)";
                break;
            case "Video":u2="inurl:"+uri+" | intitle:"+uri+" ext:\"mp4|mkv|flv\" | download inurl:(MP4|mkv|wav|flv)";
                break;
            default:Toast.makeText(MainActivity.this,
                    "Select the appropriate option", Toast.LENGTH_SHORT).show();

        }

        GooURL = "https://www.google.com/search?q=" ;

        try{

            String FinReq=GooURL+ URLEncoder.encode(u2, "UTF-8");
            //System.out.println(FinReq);

            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(FinReq));
            Intent browserIntent1 = new Intent(Intent.ACTION_VIEW, Uri.parse("http://anonhack.in"));
            startActivity(browserIntent1);

            startActivity(browserIntent);




        } catch (UnsupportedEncodingException e) {

            System.err.println(e);

        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_favorite) {
            Intent intent = new Intent(MainActivity.this, howto.class);
            startActivity(intent);
        }
        if(id==R.id.action_settings){
            Intent intent = new Intent(MainActivity.this, Aboutus.class);
            startActivity(intent);
        }


        return super.onOptionsItemSelected(item);
    }
}
